const prompt = require('prompt-sync')();
var s = prompt("Enter some string : ");
function panagram(s)
{
    let res=new Array(26).fill(0);
    let j=0;
    for(let i=0;i<s.length;i++)
    {
        if(s[i]>='A' && s[i]<='Z')
        {
            j=s.charCodeAt(i)-'A'.charCodeAt(0);
        }
        else if(s[i]>='a' && s[i]<='z')
        {
            j=s.charCodeAt(i)-'a'.charCodeAt(0);
        }
        res[j]=1;
    }
    for(let i=0;i<=25;i++)
    {
        if(res[i]==0)
        {
            return 0;
        }
    }
    return 1;
}
console.log(panagram(s));